<?php

define('PUSHERAPP_APPID', '');
define('PUSHERAPP_AUTHKEY', '');
define('PUSHERAPP_SECRET', '');
define('PUSHERAPP_HOST', 'http://api.pusherapp.com');
